<?php

namespace Filament\Forms\Components;

/**
 * @deprecated Use `MultiSelect` with the `relationship()` method instead.
 */
class BelongsToManyMultiSelect extends MultiSelect {}
