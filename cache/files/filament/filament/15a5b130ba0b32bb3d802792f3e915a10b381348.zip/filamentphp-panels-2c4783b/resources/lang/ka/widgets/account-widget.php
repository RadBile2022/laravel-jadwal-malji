<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'გასვლა',
        ],

    ],

    'welcome' => 'მოგესალმებით',

];
