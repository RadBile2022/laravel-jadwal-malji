<?php

return [

    'title' => 'Visualizza :label',

    'breadcrumb' => 'Visualizza',

    'content' => [

        'tab' => [
            'label' => 'Visualizza',
        ],

    ],

];
