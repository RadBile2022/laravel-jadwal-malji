<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Atsijungti',
        ],

    ],

    'welcome' => 'Sveiki atvykę',

];
