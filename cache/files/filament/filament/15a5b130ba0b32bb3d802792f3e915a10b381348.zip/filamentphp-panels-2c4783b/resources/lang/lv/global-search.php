<?php

return [

    'field' => [
        'label' => 'Vispārēja meklēšana',
        'placeholder' => 'Meklēt',
    ],

    'no_results_message' => 'Meklēšanas rezultāti nav atrasti.',

];
