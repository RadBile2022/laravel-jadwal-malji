<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Tancar la sessió',
        ],

    ],

    'welcome' => 'Benvingut/da',

];
