<?php

return [

    'title' => 'Խմբագրել :label',

    'breadcrumb' => 'Խմբագրել',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Չեղարկել',
            ],

            'save' => [
                'label' => 'Պահպանել',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'Խմբագրել',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Պահպանված է',
        ],

    ],

];
