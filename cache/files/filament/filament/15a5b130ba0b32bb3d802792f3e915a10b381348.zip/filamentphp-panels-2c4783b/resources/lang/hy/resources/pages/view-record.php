<?php

return [

    'title' => 'Դիտել :label',

    'breadcrumb' => 'Դիտել',

    'content' => [

        'tab' => [
            'label' => 'Դիտել',
        ],

    ],

];
