<?php

return [

    'title' => 'تعديل :label',

    'breadcrumb' => 'تعديل',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'إلغاء',
            ],

            'save' => [
                'label' => 'حفظ التغييرات',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'تعديل',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'تم الحفظ',
        ],

    ],

];
