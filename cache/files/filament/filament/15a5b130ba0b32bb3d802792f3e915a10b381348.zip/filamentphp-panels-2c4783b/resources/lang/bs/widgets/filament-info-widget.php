<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dokumentacija',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
