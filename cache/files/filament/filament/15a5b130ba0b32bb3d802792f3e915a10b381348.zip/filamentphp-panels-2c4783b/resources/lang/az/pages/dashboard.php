<?php

return [

    'title' => 'İdarəetmə Paneli',

    'actions' => [

        'filter' => [

            'label' => 'Filtr',

            'modal' => [

                'heading' => 'Filtr',

                'actions' => [

                    'apply' => [

                        'label' => 'Tətbiq et',

                    ],

                ],

            ],

        ],

    ],

];
