<?php

return [

    'title' => 'Zobrazit :label',

    'breadcrumb' => 'Zobrazit',

    'content' => [

        'tab' => [
            'label' => 'Zobrazit',
        ],

    ],

];
