<?php

return [

    'field' => [
        'label' => 'გლობალური ძიება',
        'placeholder' => 'ძიება',
    ],

    'no_results_message' => 'შედეგები ვერ მოიძებნა.',

];
