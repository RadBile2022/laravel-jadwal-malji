<?php

return [

    'breadcrumb' => 'Übersicht',

];
