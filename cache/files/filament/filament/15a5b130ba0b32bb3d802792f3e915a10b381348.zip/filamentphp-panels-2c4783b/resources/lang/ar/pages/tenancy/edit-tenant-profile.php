<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'حفظ التغييرات',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'تم الحفظ',
        ],

    ],

];
