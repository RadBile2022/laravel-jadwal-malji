<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Uložit',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Uloženo',
        ],

    ],

];
