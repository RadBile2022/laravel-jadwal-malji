<?php

return [

    'breadcrumb' => 'Списък',

];
