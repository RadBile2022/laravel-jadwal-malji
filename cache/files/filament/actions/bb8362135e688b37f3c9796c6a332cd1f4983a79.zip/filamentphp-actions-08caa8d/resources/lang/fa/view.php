<?php

return [

    'single' => [

        'label' => 'نمایش',

        'modal' => [

            'heading' => 'نمایش :label',

            'actions' => [

                'close' => [
                    'label' => 'بستن',
                ],

            ],

        ],

    ],

];
