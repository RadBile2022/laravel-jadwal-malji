<?php

return [

    'single' => [

        'label' => 'Göstər',

        'modal' => [

            'heading' => ':label göstər',

            'actions' => [

                'close' => [
                    'label' => 'Bağla',
                ],

            ],

        ],

    ],

];
