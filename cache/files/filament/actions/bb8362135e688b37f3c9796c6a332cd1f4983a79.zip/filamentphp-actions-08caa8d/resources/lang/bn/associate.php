<?php

return [

    'single' => [

        'label' => 'যুক্ত করুন',

        'modal' => [

            'heading' => ':label যুক্ত করুন',

            'fields' => [

                'record_id' => [
                    'label' => 'রেকর্ড',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'যুক্ত করুন',
                ],

                'associate_another' => [
                    'label' => 'যুক্ত এবং পুনরায় যুক্ত করুন',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'যুক্ত করা হয়েছে',
            ],

        ],

    ],

];
