<?php

return [

    'confirmation' => 'Վստա՞հ եք, որ ցանկանում եք դա անել։',

    'actions' => [

        'cancel' => [
            'label' => 'Չեղարկել',
        ],

        'confirm' => [
            'label' => 'Հաստատել',
        ],

        'submit' => [
            'label' => 'Հաստատել',
        ],

    ],

];
