<?php

return [

    'single' => [

        'label' => 'Duplizieren',

        'modal' => [

            'heading' => ':label duplizieren',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplizieren',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Eintrag dupliziert',
            ],

        ],

    ],

];
