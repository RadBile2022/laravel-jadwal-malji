<?php

return [

    'single' => [

        'label' => 'Ayır',

        'modal' => [

            'heading' => ':label ayır',

            'actions' => [

                'detach' => [
                    'label' => 'Ayır',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Ayrıldı',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Seçiləni ayır',

        'modal' => [

            'heading' => ':label seçiləni ayır ',

            'actions' => [

                'detach' => [
                    'label' => 'Seçiləni ayır',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Ayrıldı',
            ],

        ],

    ],

];
