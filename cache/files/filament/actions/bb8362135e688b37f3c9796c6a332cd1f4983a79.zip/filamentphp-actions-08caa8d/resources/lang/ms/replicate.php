<?php

return [

    'single' => [

        'label' => 'Replika',

        'modal' => [

            'heading' => 'Replika :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Replika',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Direplikasi',
            ],

        ],

    ],

];
