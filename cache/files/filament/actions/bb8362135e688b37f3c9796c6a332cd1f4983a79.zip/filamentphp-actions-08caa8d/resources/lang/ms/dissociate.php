<?php

return [

    'single' => [

        'label' => 'Nyahkait',

        'modal' => [

            'heading' => 'Nyahkait :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Nyahkait',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Ternyahkait',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Nyahkait pilihan',

        'modal' => [

            'heading' => 'Nyahkait pilihan :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Nyahkait',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Ternyahkait',
            ],

        ],

    ],

];
