<?php

return [

    'trigger' => [
        'label' => 'アクション',
    ],

];
