<?php

return [

    'single' => [

        'label' => 'Vincular',

        'modal' => [

            'heading' => 'Vincular :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Registre',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Vincular',
                ],

                'attach_another' => [
                    'label' => 'Vincular i vincular un altre',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Vinculats',
            ],

        ],

    ],

];
