<?php

return [

    'confirmation' => 'Jesi li siguran da želiš to učiniti?',

    'actions' => [

        'cancel' => [
            'label' => 'Odustani',
        ],

        'confirm' => [
            'label' => 'Potvrdi',
        ],

        'submit' => [
            'label' => 'Pošalji',
        ],

    ],

];
