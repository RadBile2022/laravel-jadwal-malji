<?php

return [

    'single' => [

        'label' => 'Lecsatolás',

        'modal' => [

            'heading' => ':label lecsatolása',

            'actions' => [

                'dissociate' => [
                    'label' => 'Lecsatolás',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Lecsatolva',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Kijelöltek lecsatolása',

        'modal' => [

            'heading' => 'Kijelölt :label lecsatolása',

            'actions' => [

                'dissociate' => [
                    'label' => 'Kijelöltek lecsatolása',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Lecsatolva',
            ],

        ],

    ],

];
