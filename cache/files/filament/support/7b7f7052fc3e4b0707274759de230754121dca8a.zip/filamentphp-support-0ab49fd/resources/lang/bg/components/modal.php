<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Затвори',
        ],

    ],

];
