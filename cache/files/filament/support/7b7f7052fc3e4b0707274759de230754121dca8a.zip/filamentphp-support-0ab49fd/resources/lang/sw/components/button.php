<?php

return [

    'messages' => [
        'uploading_file' => 'Inapakia faili...',
    ],

];
