<?php

return [

    'messages' => [
        'copied' => 'Nusxalandi',
    ],

];
