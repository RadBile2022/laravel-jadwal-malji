<?php

return [

    'messages' => [
        'uploading_file' => '正在上傳檔案...',
    ],

];
