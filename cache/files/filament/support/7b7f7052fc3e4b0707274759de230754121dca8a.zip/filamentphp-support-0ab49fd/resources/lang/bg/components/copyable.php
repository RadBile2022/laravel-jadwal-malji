<?php

return [

    'messages' => [
        'copied' => 'Копирано',
    ],

];
