<?php

return [

    'messages' => [
        'copied' => 'Kopiert',
    ],

];
