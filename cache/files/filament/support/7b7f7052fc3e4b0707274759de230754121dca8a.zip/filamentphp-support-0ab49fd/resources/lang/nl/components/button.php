<?php

return [

    'messages' => [
        'uploading_file' => 'Bestand uploaden...',
    ],

];
