<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Zatvori',
        ],

    ],

];
