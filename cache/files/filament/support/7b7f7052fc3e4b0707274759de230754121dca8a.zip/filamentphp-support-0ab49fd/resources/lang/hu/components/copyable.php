<?php

return [

    'messages' => [
        'copied' => 'Kimásolva',
    ],

];
