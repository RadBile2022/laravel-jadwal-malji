<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Փակել',
        ],

    ],

];
