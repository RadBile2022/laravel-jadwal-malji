<?php

return [

    'messages' => [
        'copied' => '已复制',
    ],

];
