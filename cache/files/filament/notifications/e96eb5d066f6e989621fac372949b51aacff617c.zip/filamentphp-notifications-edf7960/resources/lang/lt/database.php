<?php

return [

    'modal' => [

        'heading' => 'Pranešimai',

        'actions' => [

            'clear' => [
                'label' => 'Išvalyti',
            ],

            'mark_all_as_read' => [
                'label' => 'Pažymėti visus kaip perskaitytus',
            ],

        ],

        'empty' => [
            'heading' => 'Nėra pranešimų',
            'description' => 'Patikrinkite vėliau.',
        ],

    ],

];
