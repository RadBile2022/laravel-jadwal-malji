<?php

return [

    'modal' => [

        'heading' => 'Notificări',

        'actions' => [

            'clear' => [
                'label' => 'Ștergere',
            ],

            'mark_all_as_read' => [
                'label' => 'Marchează totul ca fiind citit',
            ],

        ],

        'empty' => [
            'heading' => 'Nu există notificări',
            'description' => 'Vă rugăm să verificați din nou mai târziu',
        ],

    ],

];
