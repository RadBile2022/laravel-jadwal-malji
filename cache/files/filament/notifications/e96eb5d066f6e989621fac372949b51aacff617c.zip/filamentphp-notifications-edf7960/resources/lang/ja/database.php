<?php

return [

    'modal' => [

        'heading' => '通知',

        'actions' => [

            'clear' => [
                'label' => 'クリア',
            ],

            'mark_all_as_read' => [
                'label' => 'すべて既読にする',
            ],

        ],

        'empty' => [
            'heading' => '通知はありません',
            'description' => 'のちほど確認してください',
        ],

    ],

];
