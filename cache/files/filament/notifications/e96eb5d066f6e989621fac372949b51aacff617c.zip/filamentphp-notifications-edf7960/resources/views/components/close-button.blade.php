<x-filament::icon-button
    color="gray"
    icon="heroicon-m-x-mark"
    icon-alias="notifications::notification.close-button"
    x-on:click="close"
    class="fi-no-notification-close-btn"
/>
