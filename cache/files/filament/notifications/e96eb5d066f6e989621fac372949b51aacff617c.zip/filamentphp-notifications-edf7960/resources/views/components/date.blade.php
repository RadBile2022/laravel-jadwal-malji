<time
    {{ $attributes->class(['fi-no-notification-date text-sm text-gray-500 dark:text-gray-400']) }}
>
    {{ $slot }}
</time>
