<?php

namespace Filament\Infolists\Components;

class ViewEntry extends Entry {}
