<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Afficher :count de moins',
                'expand_list' => 'Afficher :count de plus',
            ],

            'more_list_items' => 'et :count de plus',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Clé',
                ],

                'value' => [
                    'label' => 'Valeur',
                ],

            ],

            'placeholder' => 'Aucune entrée',

        ],

    ],

];
